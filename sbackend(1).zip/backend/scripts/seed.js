// Usage: npm run seed [path/to/questions.json]
// Upserts by question id, so it is safe to re-run after editing the JSON.
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mongoose from "mongoose";
import Question from "../models/Question.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const file = path.resolve(process.argv[2] ?? path.join(here, "../../questions_mongodb.json"));

if (!process.env.MONGODB_URI) {
  console.error("Missing MONGODB_URI in .env");
  process.exit(1);
}

const questions = JSON.parse(fs.readFileSync(file, "utf8"));

await mongoose.connect(process.env.MONGODB_URI);
await Question.init(); // make sure indexes exist

const result = await Question.bulkWrite(
  questions.map((q) => ({
    replaceOne: { filter: { id: q.id }, replacement: q, upsert: true },
  }))
);

console.log(`Read ${questions.length} questions from ${file}`);
console.log(`Inserted: ${result.upsertedCount}, updated: ${result.modifiedCount}`);
console.log(`Total in DB: ${await Question.countDocuments()}`);
await mongoose.disconnect();
